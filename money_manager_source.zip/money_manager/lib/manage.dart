import 'package:flutter/material.dart';
import 'models.dart';
import 'state.dart';
import 'util.dart';

class AccountsScreen extends StatelessWidget {
  final AppState s;
  const AccountsScreen(this.s, {super.key});

  Future<void> _edit(BuildContext c, Account? a) async {
    final name = TextEditingController(text: a?.name ?? '');
    final init = TextEditingController(text: a == null ? '0' : a.initial.toString());
    await showDialog(
      context: c,
      builder: (ctx) => AlertDialog(
        title: Text(a == null ? 'حساب جديد' : 'تعديل الحساب'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')),
          TextField(
              controller: init,
              keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
              decoration: const InputDecoration(labelText: 'الرصيد الابتدائي')),
        ]),
        actions: [
          if (a != null)
            TextButton(
                onPressed: () async {
                  if (await confirm(ctx, 'حذف الحساب وكل معاملاته؟')) {
                    await s.deleteAccount(a.id!);
                    if (ctx.mounted) Navigator.pop(ctx);
                  }
                },
                child: const Text('حذف')),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () async {
                if (name.text.trim().isEmpty) return;
                await s.saveAccount(Account(
                    id: a?.id,
                    name: name.text.trim(),
                    initial: parseNum(init.text) ?? 0));
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('حفظ')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) => Scaffold(
          appBar: AppBar(title: const Text('الحسابات')),
          floatingActionButton: FloatingActionButton(
              onPressed: () => _edit(context, null), child: const Icon(Icons.add)),
          body: ListView(children: [
            for (final a in s.accounts)
              ListTile(
                title: Text(a.name),
                trailing: Text(fmt(s.balance(a)),
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: s.balance(a) >= 0 ? incomeColor : expenseColor)),
                onTap: () => _edit(context, a),
              ),
          ]),
        ),
      );
}

class CategoriesScreen extends StatelessWidget {
  final AppState s;
  const CategoriesScreen(this.s, {super.key});

  Future<void> _edit(BuildContext c, Category? cat, int type) async {
    final name = await askText(c, cat == null ? 'فئة جديدة' : 'تعديل الفئة',
        initial: cat?.name);
    if (name == null || name.isEmpty) return;
    await s.saveCategory(Category(id: cat?.id, name: name, type: cat?.type ?? type));
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) => Scaffold(
          appBar: AppBar(title: const Text('الفئات')),
          body: ListView(children: [
            for (final type in [1, 0]) ...[
              ListTile(
                tileColor: Theme.of(context).colorScheme.surfaceContainerHighest,
                title: Text(type == 1 ? 'فئات المصروف' : 'فئات الدخل'),
                trailing: IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () => _edit(context, null, type)),
              ),
              for (final c in s.cats.where((c) => c.type == type))
                ListTile(
                  title: Text(c.name),
                  onTap: () => _edit(context, c, type),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      if (await confirm(context, 'حذف الفئة "${c.name}"؟')) {
                        await s.deleteCategory(c.id!);
                      }
                    },
                  ),
                ),
            ],
          ]),
        ),
      );
}

class BudgetsScreen extends StatelessWidget {
  final AppState s;
  const BudgetsScreen(this.s, {super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) => Scaffold(
          appBar: AppBar(title: const Text('الميزانيات الشهرية')),
          body: ListView(children: [
            for (final c in s.cats.where((c) => c.type == 1))
              ListTile(
                title: Text(c.name),
                trailing: Text(s.budgets[c.id] == null ? 'غير محددة' : fmt(s.budgets[c.id]!)),
                onTap: () async {
                  final v = await askText(context, 'ميزانية ${c.name} (0 للحذف)',
                      initial: s.budgets[c.id]?.toString(), number: true);
                  if (v != null) await s.setBudget(c.id!, parseNum(v));
                },
              ),
          ]),
        ),
      );
}

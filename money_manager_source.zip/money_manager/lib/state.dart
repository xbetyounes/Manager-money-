import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart' show ConflictAlgorithm;
import 'db.dart';
import 'models.dart';

class AppState extends ChangeNotifier {
  List<Account> accounts = [];
  List<Category> cats = [];
  List<Txn> txns = [];
  Map<int, double> budgets = {};
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month);

  Future<void> load() async {
    final d = await Db.get();
    accounts = (await d.query('accounts')).map(Account.fromMap).toList();
    cats = (await d.query('categories')).map(Category.fromMap).toList();
    txns = (await d.query('txns', orderBy: 'date DESC, id DESC'))
        .map(Txn.fromMap)
        .toList();
    budgets = {
      for (final r in await d.query('budgets'))
        r['category_id'] as int: (r['amount'] as num).toDouble()
    };
    notifyListeners();
  }

  void setMonth(DateTime m) {
    month = DateTime(m.year, m.month);
    notifyListeners();
  }

  List<Txn> inMonth(DateTime m) =>
      txns.where((t) => t.date.year == m.year && t.date.month == m.month).toList();

  double sum(Iterable<Txn> l, int type) =>
      l.where((t) => t.type == type).fold(0.0, (a, t) => a + t.amount);

  String catName(int? id) {
    for (final c in cats) {
      if (c.id == id) return c.name;
    }
    return 'بدون فئة';
  }

  String accName(int? id) {
    for (final a in accounts) {
      if (a.id == id) return a.name;
    }
    return '-';
  }

  double balance(Account a) {
    var b = a.initial;
    for (final t in txns) {
      if (t.type == 0 && t.accountId == a.id) b += t.amount;
      if (t.type == 1 && t.accountId == a.id) b -= t.amount;
      if (t.type == 2) {
        if (t.accountId == a.id) b -= t.amount;
        if (t.toAccountId == a.id) b += t.amount;
      }
    }
    return b;
  }

  Future<void> saveAccount(Account a) async {
    final d = await Db.get();
    if (a.id == null) {
      await d.insert('accounts', a.toMap());
    } else {
      await d.update('accounts', a.toMap(), where: 'id=?', whereArgs: [a.id]);
    }
    await load();
  }

  Future<void> deleteAccount(int id) async {
    final d = await Db.get();
    await d.delete('txns', where: 'account_id=? OR to_account_id=?', whereArgs: [id, id]);
    await d.delete('accounts', where: 'id=?', whereArgs: [id]);
    await load();
  }

  Future<void> saveCategory(Category c) async {
    final d = await Db.get();
    if (c.id == null) {
      await d.insert('categories', c.toMap());
    } else {
      await d.update('categories', c.toMap(), where: 'id=?', whereArgs: [c.id]);
    }
    await load();
  }

  Future<void> deleteCategory(int id) async {
    final d = await Db.get();
    await d.update('txns', {'category_id': null}, where: 'category_id=?', whereArgs: [id]);
    await d.delete('budgets', where: 'category_id=?', whereArgs: [id]);
    await d.delete('categories', where: 'id=?', whereArgs: [id]);
    await load();
  }

  Future<void> setBudget(int catId, double? amount) async {
    final d = await Db.get();
    if (amount == null || amount <= 0) {
      await d.delete('budgets', where: 'category_id=?', whereArgs: [catId]);
    } else {
      await d.insert('budgets', {'category_id': catId, 'amount': amount},
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await load();
  }

  Future<void> saveTxn(Txn t) async {
    final d = await Db.get();
    if (t.id == null) {
      await d.insert('txns', t.toMap());
    } else {
      await d.update('txns', t.toMap(), where: 'id=?', whereArgs: [t.id]);
    }
    await load();
  }

  Future<void> deleteTxn(int id) async {
    final d = await Db.get();
    await d.delete('txns', where: 'id=?', whereArgs: [id]);
    await load();
  }

  Future<String> exportJson() async => jsonEncode({
        'v': 1,
        'accounts': accounts.map((e) => e.toMap()).toList(),
        'categories': cats.map((e) => e.toMap()).toList(),
        'txns': txns.map((e) => e.toMap()).toList(),
        'budgets': budgets.entries
            .map((e) => {'category_id': e.key, 'amount': e.value})
            .toList(),
      });

  Future<void> importJson(String s) async {
    final j = jsonDecode(s) as Map<String, dynamic>;
    final d = await Db.get();
    await d.transaction((tx) async {
      for (final t in ['accounts', 'categories', 'txns', 'budgets']) {
        await tx.delete(t);
        for (final m in (j[t] as List? ?? [])) {
          await tx.insert(t, Map<String, Object?>.from(m as Map));
        }
      }
    });
    await load();
  }
}

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'models.dart';
import 'state.dart';
import 'util.dart';

class TxnEditScreen extends StatefulWidget {
  final AppState s;
  final Txn? txn;
  const TxnEditScreen(this.s, {super.key, this.txn});
  @override
  State<TxnEditScreen> createState() => _TxnEditState();
}

class _TxnEditState extends State<TxnEditScreen> {
  late int type;
  late DateTime date;
  late TextEditingController amount, note;
  int? cat, acc, toAcc;

  @override
  void initState() {
    super.initState();
    final t = widget.txn;
    type = t?.type ?? 1;
    date = t?.date ?? DateTime.now();
    amount = TextEditingController(
        text: t == null ? '' : (t.amount % 1 == 0 ? t.amount.toInt().toString() : t.amount.toString()));
    note = TextEditingController(text: t?.note ?? '');
    cat = t?.categoryId;
    acc = t?.accountId ??
        (widget.s.accounts.isNotEmpty ? widget.s.accounts.first.id : null);
    toAcc = t?.toAccountId;
  }

  Future<void> save() async {
    final a = parseNum(amount.text);
    if (a == null || a <= 0) return toast(context, 'أدخل مبلغاً صحيحاً');
    if (acc == null) return toast(context, 'اختر الحساب');
    if (type != 2 && cat == null) return toast(context, 'اختر الفئة');
    if (type == 2 && (toAcc == null || toAcc == acc)) {
      return toast(context, 'اختر حساباً مختلفاً للتحويل');
    }
    await widget.s.saveTxn(Txn(
      id: widget.txn?.id,
      date: date,
      type: type,
      amount: a,
      categoryId: type == 2 ? null : cat,
      accountId: acc!,
      toAccountId: type == 2 ? toAcc : null,
      note: note.text.trim(),
    ));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.txn == null ? 'معاملة جديدة' : 'تعديل المعاملة'),
        actions: [
          if (widget.txn != null)
            IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () async {
                if (await confirm(context, 'حذف هذه المعاملة؟')) {
                  await s.deleteTxn(widget.txn!.id!);
                  if (context.mounted) Navigator.pop(context);
                }
              },
            ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        SegmentedButton<int>(
          segments: const [
            ButtonSegment(value: 0, label: Text('دخل')),
            ButtonSegment(value: 1, label: Text('مصروف')),
            ButtonSegment(value: 2, label: Text('تحويل')),
          ],
          selected: {type},
          onSelectionChanged: (v) => setState(() {
            type = v.first;
            cat = null;
          }),
        ),
        const SizedBox(height: 12),
        ListTile(
          leading: const Icon(Icons.event),
          title: Text(DateFormat.yMMMMd('ar').format(date)),
          onTap: () async {
            final d = await showDatePicker(
                context: context,
                initialDate: date,
                firstDate: DateTime(2000),
                lastDate: DateTime(2100));
            if (d != null) setState(() => date = d);
          },
        ),
        TextField(
          controller: amount,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'المبلغ'),
        ),
        const SizedBox(height: 8),
        if (type != 2)
          DropdownButtonFormField<int>(
            value: cat,
            decoration: const InputDecoration(labelText: 'الفئة'),
            items: [
              for (final c in s.cats.where((c) => c.type == type))
                DropdownMenuItem(value: c.id, child: Text(c.name)),
            ],
            onChanged: (v) => setState(() => cat = v),
          ),
        DropdownButtonFormField<int>(
          value: acc,
          decoration: InputDecoration(labelText: type == 2 ? 'من حساب' : 'الحساب'),
          items: [
            for (final a in s.accounts)
              DropdownMenuItem(value: a.id, child: Text(a.name)),
          ],
          onChanged: (v) => setState(() => acc = v),
        ),
        if (type == 2)
          DropdownButtonFormField<int>(
            value: toAcc,
            decoration: const InputDecoration(labelText: 'إلى حساب'),
            items: [
              for (final a in s.accounts)
                DropdownMenuItem(value: a.id, child: Text(a.name)),
            ],
            onChanged: (v) => setState(() => toAcc = v),
          ),
        TextField(
          controller: note,
          decoration: const InputDecoration(labelText: 'ملاحظة'),
        ),
        const SizedBox(height: 24),
        FilledButton(onPressed: save, child: const Text('حفظ')),
      ]),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

String fmt(double v) => NumberFormat('#,##0.##').format(v);
const incomeColor = Color(0xFF2E7D32);
const expenseColor = Color(0xFFC62828);

double? parseNum(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  var r = s.trim().replaceAll('٫', '.').replaceAll('،', '').replaceAll(',', '');
  for (var i = 0; i < 10; i++) {
    r = r.replaceAll(ar[i], '$i');
  }
  return double.tryParse(r);
}

void toast(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

Future<String?> askText(BuildContext c, String title,
    {String? initial, bool number = false}) {
  final ctl = TextEditingController(text: initial ?? '');
  return showDialog<String>(
      context: c,
      builder: (ctx) => AlertDialog(
            title: Text(title),
            content: TextField(
              controller: ctl,
              autofocus: true,
              keyboardType: number
                  ? const TextInputType.numberWithOptions(decimal: true)
                  : TextInputType.text,
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
              FilledButton(
                  onPressed: () => Navigator.pop(ctx, ctl.text.trim()),
                  child: const Text('حفظ')),
            ],
          ));
}

Future<bool> confirm(BuildContext c, String msg) async =>
    (await showDialog<bool>(
        context: c,
        builder: (ctx) => AlertDialog(content: Text(msg), actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لا')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('نعم')),
            ]))) ==
    true;

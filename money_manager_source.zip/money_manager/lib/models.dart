class Account {
  int? id;
  String name;
  double initial;
  Account({this.id, required this.name, this.initial = 0});
  Map<String, Object?> toMap() => {'id': id, 'name': name, 'initial': initial};
  factory Account.fromMap(Map<String, Object?> m) => Account(
      id: m['id'] as int?,
      name: m['name'] as String,
      initial: (m['initial'] as num).toDouble());
}

/// type: 0 = دخل, 1 = مصروف
class Category {
  int? id;
  String name;
  int type;
  Category({this.id, required this.name, required this.type});
  Map<String, Object?> toMap() => {'id': id, 'name': name, 'type': type};
  factory Category.fromMap(Map<String, Object?> m) => Category(
      id: m['id'] as int?, name: m['name'] as String, type: m['type'] as int);
}

/// type: 0 = دخل, 1 = مصروف, 2 = تحويل
class Txn {
  int? id;
  DateTime date;
  int type;
  double amount;
  int? categoryId;
  int accountId;
  int? toAccountId;
  String note;
  Txn(
      {this.id,
      required this.date,
      required this.type,
      required this.amount,
      this.categoryId,
      required this.accountId,
      this.toAccountId,
      this.note = ''});
  Map<String, Object?> toMap() => {
        'id': id,
        'date': date.millisecondsSinceEpoch,
        'type': type,
        'amount': amount,
        'category_id': categoryId,
        'account_id': accountId,
        'to_account_id': toAccountId,
        'note': note,
      };
  factory Txn.fromMap(Map<String, Object?> m) => Txn(
        id: m['id'] as int?,
        date: DateTime.fromMillisecondsSinceEpoch(m['date'] as int),
        type: m['type'] as int,
        amount: (m['amount'] as num).toDouble(),
        categoryId: m['category_id'] as int?,
        accountId: m['account_id'] as int,
        toAccountId: m['to_account_id'] as int?,
        note: (m['note'] as String?) ?? '',
      );
}

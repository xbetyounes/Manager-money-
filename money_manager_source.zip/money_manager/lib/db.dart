import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class Db {
  static Database? _db;
  static Future<Database> get() async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'money.db');
    _db = await openDatabase(path, version: 1, onCreate: (d, v) async {
      await d.execute(
          'CREATE TABLE accounts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, initial REAL)');
      await d.execute(
          'CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, type INTEGER)');
      await d.execute(
          'CREATE TABLE txns(id INTEGER PRIMARY KEY AUTOINCREMENT, date INTEGER, type INTEGER, amount REAL, category_id INTEGER, account_id INTEGER, to_account_id INTEGER, note TEXT)');
      await d.execute(
          'CREATE TABLE budgets(category_id INTEGER PRIMARY KEY, amount REAL)');
      for (final n in ['نقدي', 'حساب بنكي', 'بطاقة']) {
        await d.insert('accounts', {'name': n, 'initial': 0.0});
      }
      for (final n in ['طعام', 'مواصلات', 'فواتير', 'تسوق', 'صحة', 'ترفيه', 'تعليم', 'أخرى']) {
        await d.insert('categories', {'name': n, 'type': 1});
      }
      for (final n in ['راتب', 'أعمال', 'هدية', 'أخرى']) {
        await d.insert('categories', {'name': n, 'type': 0});
      }
    });
    return _db!;
  }
}

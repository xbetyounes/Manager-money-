import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'cloud.dart';
import 'state.dart';
import 'util.dart';

class SyncScreen extends StatefulWidget {
  final AppState s;
  const SyncScreen(this.s, {super.key});
  @override
  State<SyncScreen> createState() => _SyncState();
}

class _SyncState extends State<SyncScreen> {
  static const keys = [
    'wd_url', 'wd_user', 'wd_pass',
    'nc_server', 'nc_user', 'nc_pass',
    'db_key', 'od_client',
  ];
  final c = {for (final k in keys) k: TextEditingController()};
  SharedPreferences? prefs;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      prefs = p;
      for (final k in keys) {
        c[k]!.text = p.getString(k) ?? '';
      }
      if (mounted) setState(() {});
    });
  }

  Future<void> _saveFields() async {
    for (final k in keys) {
      await prefs!.setString(k, c[k]!.text.trim());
    }
  }

  CloudProvider? _provider(String kind) {
    final p = prefs!;
    switch (kind) {
      case 'wd':
        if (c['wd_url']!.text.isEmpty) return null;
        return WebDavProvider(c['wd_url']!.text.trim(), c['wd_user']!.text.trim(), c['wd_pass']!.text);
      case 'nc':
        if (c['nc_server']!.text.isEmpty) return null;
        return NextcloudProvider(c['nc_server']!.text.trim(), c['nc_user']!.text.trim(), c['nc_pass']!.text);
      case 'db':
        final r = p.getString('db_refresh');
        if (r == null) return null;
        return DropboxProvider(c['db_key']!.text.trim(), r);
      case 'od':
        final r = p.getString('od_refresh');
        if (r == null) return null;
        return OneDriveProvider(c['od_client']!.text.trim(), r);
    }
    return null;
  }

  Future<void> _run(Future<void> Function() f) async {
    setState(() => busy = true);
    try {
      await _saveFields();
      await f();
    } catch (e) {
      if (mounted) toast(context, 'خطأ: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _upload(String kind) => _run(() async {
        final p = _provider(kind);
        if (p == null) return toast(context, 'أكمل الإعدادات / اربط الحساب أولاً');
        await p.upload(await widget.s.exportJson());
        if (mounted) toast(context, 'تم رفع النسخة الاحتياطية');
      });

  Future<void> _restore(String kind) => _run(() async {
        final p = _provider(kind);
        if (p == null) return toast(context, 'أكمل الإعدادات / اربط الحساب أولاً');
        final data = await p.download();
        if (data == null) return toast(context, 'لا توجد نسخة احتياطية في هذا الحساب');
        if (!mounted) return;
        if (!await confirm(context, 'سيتم استبدال كل البيانات الحالية بالنسخة السحابية. متابعة؟')) return;
        await widget.s.importJson(data);
        if (mounted) toast(context, 'تمت الاستعادة');
      });

  Future<void> _linkDropbox() => _run(() async {
        final key = c['db_key']!.text.trim();
        if (key.isEmpty) return toast(context, 'أدخل App Key');
        await launchUrl(DropboxProvider.startAuth(key), mode: LaunchMode.externalApplication);
        if (!mounted) return;
        final code = await askText(context, 'الصق رمز التفويض الذي ظهر في Dropbox');
        if (code == null || code.isEmpty) return;
        final rt = await DropboxProvider.finishAuth(key, code);
        await prefs!.setString('db_refresh', rt);
        if (mounted) toast(context, 'تم ربط Dropbox');
      });

  Future<void> _linkOneDrive() async {
    final id = c['od_client']!.text.trim();
    if (id.isEmpty) return toast(context, 'أدخل Application (client) ID');
    await _saveFields();
    try {
      final d = await OneDriveProvider.startDevice(id);
      if (!mounted) return;
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => PopScope(
          canPop: false,
          child: AlertDialog(
            title: const Text('ربط OneDrive'),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('افتح الرابط وأدخل هذا الرمز:'),
              const SizedBox(height: 8),
              SelectableText('${d['user_code']}',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              TextButton(
                  onPressed: () => launchUrl(Uri.parse('${d['verification_uri']}'),
                      mode: LaunchMode.externalApplication),
                  child: Text('${d['verification_uri']}')),
              const SizedBox(height: 8),
              const LinearProgressIndicator(),
            ]),
          ),
        ),
      );
      try {
        final rt = await OneDriveProvider.pollDevice(id, d);
        await prefs!.setString('od_refresh', rt);
        if (mounted) toast(context, 'تم ربط OneDrive');
      } finally {
        if (mounted) Navigator.of(context, rootNavigator: true).pop();
      }
    } catch (e) {
      if (mounted) toast(context, 'خطأ: $e');
    }
    if (mounted) setState(() {});
  }

  Widget _field(String k, String label, {bool pass = false}) => TextField(
        controller: c[k],
        obscureText: pass,
        decoration: InputDecoration(labelText: label),
      );

  Widget _buttons(String kind) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Wrap(spacing: 8, children: [
          FilledButton.icon(
              onPressed: busy ? null : () => _upload(kind),
              icon: const Icon(Icons.cloud_upload),
              label: const Text('رفع نسخة')),
          OutlinedButton.icon(
              onPressed: busy ? null : () => _restore(kind),
              icon: const Icon(Icons.cloud_download),
              label: const Text('استعادة')),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    if (prefs == null) {
      return Scaffold(
          appBar: AppBar(title: const Text('المزامنة السحابية')),
          body: const Center(child: CircularProgressIndicator()));
    }
    final dbLinked = prefs!.getString('db_refresh') != null;
    final odLinked = prefs!.getString('od_refresh') != null;
    return Scaffold(
      appBar: AppBar(title: const Text('المزامنة السحابية')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        if (busy) const LinearProgressIndicator(),
        Card(
          child: ExpansionTile(
            leading: const Icon(Icons.cloud),
            title: const Text('Dropbox'),
            subtitle: Text(dbLinked ? 'مرتبط ✓' : 'غير مرتبط'),
            childrenPadding: const EdgeInsets.all(12),
            children: [
              _field('db_key', 'App Key (من Dropbox App Console)'),
              Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: TextButton(
                      onPressed: busy ? null : _linkDropbox,
                      child: const Text('ربط الحساب'))),
              _buttons('db'),
            ],
          ),
        ),
        Card(
          child: ExpansionTile(
            leading: const Icon(Icons.cloud_queue),
            title: const Text('OneDrive'),
            subtitle: Text(odLinked ? 'مرتبط ✓' : 'غير مرتبط'),
            childrenPadding: const EdgeInsets.all(12),
            children: [
              _field('od_client', 'Application (client) ID (من Azure)'),
              Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: TextButton(
                      onPressed: busy ? null : _linkOneDrive,
                      child: const Text('ربط الحساب'))),
              _buttons('od'),
            ],
          ),
        ),
        Card(
          child: ExpansionTile(
            leading: const Icon(Icons.cloud_circle),
            title: const Text('Nextcloud'),
            childrenPadding: const EdgeInsets.all(12),
            children: [
              _field('nc_server', 'عنوان الخادم (https://cloud.example.com)'),
              _field('nc_user', 'اسم المستخدم'),
              _field('nc_pass', 'كلمة مرور التطبيق', pass: true),
              _buttons('nc'),
            ],
          ),
        ),
        Card(
          child: ExpansionTile(
            leading: const Icon(Icons.storage),
            title: const Text('WebDAV'),
            childrenPadding: const EdgeInsets.all(12),
            children: [
              _field('wd_url', 'رابط المجلد (https://host/dav/folder/)'),
              _field('wd_user', 'اسم المستخدم'),
              _field('wd_pass', 'كلمة المرور', pass: true),
              _buttons('wd'),
            ],
          ),
        ),
      ]),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'manage.dart';
import 'models.dart';
import 'state.dart';
import 'sync.dart';
import 'txn_edit.dart';
import 'util.dart';

class HomeScreen extends StatefulWidget {
  final AppState s;
  const HomeScreen(this.s, {super.key});
  @override
  State<HomeScreen> createState() => _HomeState();
}

class _HomeState extends State<HomeScreen> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        final pages = <Widget>[
          DailyTab(s),
          CalendarTab(s),
          MonthlyTab(s),
          StatsTab(s),
          MoreTab(s),
        ];
        final m = s.month;
        return Scaffold(
          appBar: AppBar(
            centerTitle: true,
            title: Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () => s.setMonth(DateTime(m.year, m.month - 1))),
              Text(tab == 2
                  ? '${m.year}'
                  : DateFormat.yMMMM('ar').format(m)),
              IconButton(
                  icon: const Icon(Icons.arrow_forward),
                  onPressed: () => s.setMonth(DateTime(m.year, m.month + 1))),
            ]),
          ),
          body: Column(children: [
            if (tab != 4) SummaryBar(s),
            Expanded(child: pages[tab]),
          ]),
          floatingActionButton: FloatingActionButton(
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => TxnEditScreen(s))),
            child: const Icon(Icons.add),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.view_list), label: 'يومي'),
              NavigationDestination(icon: Icon(Icons.calendar_month), label: 'تقويم'),
              NavigationDestination(icon: Icon(Icons.bar_chart), label: 'شهري'),
              NavigationDestination(icon: Icon(Icons.pie_chart), label: 'إحصاءات'),
              NavigationDestination(icon: Icon(Icons.more_horiz), label: 'المزيد'),
            ],
          ),
        );
      },
    );
  }
}

class SummaryBar extends StatelessWidget {
  final AppState s;
  const SummaryBar(this.s, {super.key});
  @override
  Widget build(BuildContext context) {
    final l = s.inMonth(s.month);
    final inc = s.sum(l, 0), exp = s.sum(l, 1);
    Widget cell(String t, double v, Color c) => Expanded(
          child: Column(children: [
            Text(t, style: const TextStyle(fontSize: 12)),
            Text(fmt(v),
                style: TextStyle(color: c, fontWeight: FontWeight.bold)),
          ]),
        );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(children: [
        cell('الدخل', inc, incomeColor),
        cell('المصروف', exp, expenseColor),
        cell('الرصيد', inc - exp, inc - exp >= 0 ? incomeColor : expenseColor),
      ]),
    );
  }
}

class TxnTile extends StatelessWidget {
  final AppState s;
  final Txn t;
  const TxnTile(this.s, this.t, {super.key});
  @override
  Widget build(BuildContext context) {
    final color = t.type == 0
        ? incomeColor
        : t.type == 1
            ? expenseColor
            : Colors.blueGrey;
    final acc = t.type == 2
        ? '${s.accName(t.accountId)} ← ${s.accName(t.toAccountId)}'
        : s.accName(t.accountId);
    return ListTile(
      title: Text(t.type == 2 ? 'تحويل' : s.catName(t.categoryId)),
      subtitle: Text([acc, t.note].where((e) => e.isNotEmpty).join(' • ')),
      trailing: Text(fmt(t.amount),
          style: TextStyle(color: color, fontWeight: FontWeight.bold)),
      onTap: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => TxnEditScreen(s, txn: t))),
    );
  }
}

class DailyTab extends StatelessWidget {
  final AppState s;
  const DailyTab(this.s, {super.key});
  @override
  Widget build(BuildContext context) {
    final list = s.inMonth(s.month);
    if (list.isEmpty) return const Center(child: Text('لا توجد معاملات هذا الشهر'));
    final days = <DateTime, List<Txn>>{};
    for (final t in list) {
      days.putIfAbsent(DateTime(t.date.year, t.date.month, t.date.day), () => []).add(t);
    }
    final keys = days.keys.toList()..sort((a, b) => b.compareTo(a));
    return ListView(children: [
      for (final k in keys) ...[
        Container(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Row(children: [
            Expanded(child: Text(DateFormat('d EEEE', 'ar').format(k))),
            Text(fmt(s.sum(days[k]!, 0)),
                style: const TextStyle(color: incomeColor)),
            const SizedBox(width: 16),
            Text(fmt(s.sum(days[k]!, 1)),
                style: const TextStyle(color: expenseColor)),
          ]),
        ),
        for (final t in days[k]!) TxnTile(s, t),
      ],
      const SizedBox(height: 80),
    ]);
  }
}

class CalendarTab extends StatefulWidget {
  final AppState s;
  const CalendarTab(this.s, {super.key});
  @override
  State<CalendarTab> createState() => _CalState();
}

class _CalState extends State<CalendarTab> {
  DateTime? sel;
  @override
  Widget build(BuildContext context) {
    final s = widget.s, m = s.month;
    final first = DateTime(m.year, m.month, 1);
    final n = DateTime(m.year, m.month + 1, 0).day;
    final offset = first.weekday % 7;
    final byDay = <int, List<Txn>>{};
    for (final t in s.inMonth(m)) {
      byDay.putIfAbsent(t.date.day, () => []).add(t);
    }
    const names = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
    final selDay = (sel != null && sel!.year == m.year && sel!.month == m.month)
        ? sel!.day
        : null;
    return Column(children: [
      Row(children: [
        for (final d in names)
          Expanded(child: Center(child: Text(d, style: const TextStyle(fontSize: 11)))),
      ]),
      GridView.count(
        crossAxisCount: 7,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 0.8,
        children: [
          for (var i = 0; i < offset; i++) const SizedBox(),
          for (var d = 1; d <= n; d++)
            InkWell(
              onTap: () => setState(() => sel = DateTime(m.year, m.month, d)),
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(
                      color: selDay == d
                          ? Theme.of(context).colorScheme.primary
                          : Colors.transparent),
                ),
                child: Column(children: [
                  Text('$d'),
                  if (s.sum(byDay[d] ?? [], 0) > 0)
                    Text(fmt(s.sum(byDay[d]!, 0)),
                        style: const TextStyle(fontSize: 9, color: incomeColor)),
                  if (s.sum(byDay[d] ?? [], 1) > 0)
                    Text(fmt(s.sum(byDay[d]!, 1)),
                        style: const TextStyle(fontSize: 9, color: expenseColor)),
                ]),
              ),
            ),
        ],
      ),
      const Divider(height: 1),
      Expanded(
        child: ListView(children: [
          if (selDay != null)
            for (final t in byDay[selDay] ?? <Txn>[]) TxnTile(s, t),
        ]),
      ),
    ]);
  }
}

class MonthlyTab extends StatelessWidget {
  final AppState s;
  const MonthlyTab(this.s, {super.key});
  @override
  Widget build(BuildContext context) {
    final y = s.month.year;
    return ListView(children: [
      for (var m = 12; m >= 1; m--)
        Builder(builder: (context) {
          final l = s.inMonth(DateTime(y, m));
          final inc = s.sum(l, 0), exp = s.sum(l, 1);
          return ListTile(
            selected: s.month.month == m,
            title: Text(DateFormat.MMMM('ar').format(DateTime(y, m))),
            subtitle: Row(children: [
              Text(fmt(inc), style: const TextStyle(color: incomeColor)),
              const SizedBox(width: 16),
              Text(fmt(exp), style: const TextStyle(color: expenseColor)),
            ]),
            trailing: Text(fmt(inc - exp),
                style: const TextStyle(fontWeight: FontWeight.bold)),
            onTap: () => s.setMonth(DateTime(y, m)),
          );
        }),
      const SizedBox(height: 80),
    ]);
  }
}

class StatsTab extends StatefulWidget {
  final AppState s;
  const StatsTab(this.s, {super.key});
  @override
  State<StatsTab> createState() => _StatsState();
}

class _StatsState extends State<StatsTab> {
  int type = 1;
  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final l = s.inMonth(s.month).where((t) => t.type == type);
    final byCat = <int?, double>{};
    for (final t in l) {
      byCat[t.categoryId] = (byCat[t.categoryId] ?? 0) + t.amount;
    }
    final total = byCat.values.fold(0.0, (a, b) => a + b);
    final entries = byCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return ListView(padding: const EdgeInsets.all(12), children: [
      SegmentedButton<int>(
        segments: const [
          ButtonSegment(value: 1, label: Text('المصروف')),
          ButtonSegment(value: 0, label: Text('الدخل')),
        ],
        selected: {type},
        onSelectionChanged: (v) => setState(() => type = v.first),
      ),
      const SizedBox(height: 12),
      if (entries.isEmpty) const Center(child: Text('لا توجد بيانات')),
      for (final e in entries)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(s.catName(e.key))),
              Text('${fmt(e.value)}  (${(e.value / total * 100).toStringAsFixed(1)}%)'),
            ]),
            const SizedBox(height: 4),
            LinearProgressIndicator(
                value: e.value / total,
                color: type == 0 ? incomeColor : expenseColor),
            if (type == 1 && e.key != null && s.budgets[e.key] != null) ...[
              const SizedBox(height: 4),
              Text(
                'الميزانية: ${fmt(s.budgets[e.key]!)}  •  المتبقي: ${fmt(s.budgets[e.key]! - e.value)}',
                style: TextStyle(
                    fontSize: 12,
                    color: e.value > s.budgets[e.key]! ? expenseColor : null),
              ),
            ],
          ]),
        ),
    ]);
  }
}

class MoreTab extends StatelessWidget {
  final AppState s;
  const MoreTab(this.s, {super.key});
  @override
  Widget build(BuildContext context) {
    void go(Widget w) =>
        Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    return ListView(children: [
      ListTile(
          leading: const Icon(Icons.account_balance_wallet),
          title: const Text('الحسابات'),
          onTap: () => go(AccountsScreen(s))),
      ListTile(
          leading: const Icon(Icons.category),
          title: const Text('الفئات'),
          onTap: () => go(CategoriesScreen(s))),
      ListTile(
          leading: const Icon(Icons.savings),
          title: const Text('الميزانيات'),
          onTap: () => go(BudgetsScreen(s))),
      ListTile(
          leading: const Icon(Icons.cloud_sync),
          title: const Text('النسخ الاحتياطي والمزامنة السحابية'),
          onTap: () => go(SyncScreen(s))),
    ]);
  }
}

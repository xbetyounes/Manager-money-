# مدير أموالي (Flutter)

## الحصول على APK بدون أي بيئة تطوير
1. أنشئ مستودعاً جديداً على GitHub وارفع محتويات هذا المجلد (فك الضغط ثم Upload files).
2. افتح تبويب **Actions** ← **Build APK** ← **Run workflow**.
3. بعد دقائق نزّل `money-manager-apk` من قسم Artifacts (داخله app-release.apk).

## إعداد الخدمات السحابية (مرة واحدة)
- **Dropbox**: أنشئ تطبيقاً في Dropbox App Console (Scoped access، App folder)، فعّل صلاحيتي files.content.read/write، وانسخ App Key.
- **OneDrive**: سجّل تطبيقاً في Azure (Personal Microsoft accounts)، فعّل Allow public client flows، أضف صلاحية Files.ReadWrite.AppFolder، وانسخ Application (client) ID.
- **Nextcloud / WebDAV**: عنوان الخادم + اسم المستخدم + كلمة مرور (يُفضّل App Password).

## الهيكل
lib/models.dart, db.dart (SQLite) • state.dart (الحالة) • home.dart (التبويبات) • txn_edit.dart • manage.dart (حسابات/فئات/ميزانيات) • cloud.dart (4 مزودين) • sync.dart
